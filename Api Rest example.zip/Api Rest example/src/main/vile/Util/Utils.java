package Util;

import dto.ClienteDTO;
import model.Cliente;

import java.util.ArrayList;
import java.util.List;


public class Utils {

    public static ClienteDTO copiaPropiedadesCliente(Cliente cliente){
        ClienteDTO dto = new ClienteDTO();
        dto.setId(cliente.getId());
        dto.setEdad(cliente.getEdad());
        dto.setNombre(cliente.getNombre());
        dto.setPrimerApellido(cliente.getPrimerApellido());
        dto.setSegundoApellido(cliente.getSegundoApellido());
        dto.setNif(cliente.getNif());
        return dto;
    }

    public static List<ClienteDTO> copiaPropiedadesClienteList(List<Cliente>clientes){
        List<ClienteDTO> listaClientes= new ArrayList<ClienteDTO>();
            if(clientes!=null && !clientes.isEmpty()){
                for(Cliente cliente: clientes){
                    listaClientes.add(copiaPropiedadesCliente(cliente));
                }
            }
            return listaClientes;
    }

    public static Cliente copiaPropiedadesClienteDTO(ClienteDTO dto) {
        Cliente cliente = new Cliente();
        cliente.setId(dto.getId());
        cliente.setEdad(dto.getEdad());
        cliente.setNombre(dto.getNombre());
        cliente.setPrimerApellido(dto.getPrimerApellido());
        cliente.setSegundoApellido(dto.getSegundoApellido());
        cliente.setNif(dto.getNif());
        return cliente;
    }
}
