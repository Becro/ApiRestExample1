package controller;


import dto.ClienteDTO;
import lombok.extern.slf4j.Slf4j;
import model.Cliente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import service.ClienteService;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/clientes")
public class ClienteController {
    @Autowired
    private ClienteService clienteService;

    @PostMapping("/alta")
    public ClienteDTO alta(@RequestBody Cliente cliente){
        return clienteService.alta(cliente);
    }
    @PutMapping("/modificacion")
    public ClienteDTO modificacion(@RequestBody Cliente cliente){
        return clienteService.modificacion(cliente);
    }
    @GetMapping("/consulta/{idCliente}")
    public ClienteDTO consulta(@PathVariable("idCliente") Integer idCliente){
        return clienteService.consulta(idCliente);
    }
    @GetMapping("/consulta")
    public List<ClienteDTO> consulta(){
        return clienteService.consulta();
    }
    @DeleteMapping("/eliminar/{idCliente}")
    public Integer eliminarCliente(@PathVariable("idCliente") Integer idCliente){
        return clienteService.borrar(idCliente);
    }

}
