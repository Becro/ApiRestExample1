package service;

import dto.ClienteDTO;
import model.Cliente;

import java.util.List;

public interface ClienteService {
    ClienteDTO alta(Cliente cliente);
    ClienteDTO modificacion(Cliente cliente);
    ClienteDTO consulta(Integer id);
    List<ClienteDTO> consulta();
    Integer borrar(Integer idCliente);
}
