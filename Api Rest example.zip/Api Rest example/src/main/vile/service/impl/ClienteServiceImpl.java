package service.impl;

import Util.Utils;
import dto.ClienteDTO;
import model.Cliente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repository.ClienteRepository;
import service.ClienteService;

import java.util.List;

@Service
public class ClienteServiceImpl implements ClienteService {
    @Autowired
    private ClienteRepository clienteRepository;
    public ClienteDTO alta(Cliente cliente) {
        clienteRepository.save(cliente);
        return Utils.copiaPropiedadesCliente(cliente);
    }

    public ClienteDTO modificacion(Cliente cliente) {
        clienteRepository.save(cliente);

        return Utils.copiaPropiedadesCliente(cliente);
    }

    public ClienteDTO consulta(Integer id) {
        return Utils.copiaPropiedadesCliente(clienteRepository.getById(id));
    }

    public List<ClienteDTO> consulta() {
        return Utils.copiaPropiedadesClienteList(clienteRepository.findAll());
    }

    public Integer borrar(Integer idCliente) {
        ClienteDTO dto = this.consulta(idCliente);
        Cliente cliente = Utils.copiaPropiedadesClienteDTO(dto);
        clienteRepository.delete(cliente);
        return idCliente;
    }


}
