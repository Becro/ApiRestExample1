package model;



import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;


@Entity
@Table(name = "CLIENTE")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Cliente {
    @Id
    @PrimaryKeyJoinColumn
    @Column
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    @Column
    @NonNull
    private String nombre;
    @Column
    @NonNull
    private String primerApellido;
    @Column
    @NonNull
    private String segundoApellido;
    @Column
    @NonNull
    private Integer edad;
    @Column
    @NonNull
    private String nif;

}
