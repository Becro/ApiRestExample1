INSERT INTO Cliente (nombre, primerApellido, segundoApellido, edad, nif) VALUES ('Juan', 'Gomez', 'Lopez', 30, '12345678A');
INSERT INTO Cliente (nombre, primerApellido, segundoApellido, edad, nif) VALUES ('Maria', 'Martinez', 'Garcia', 25, '87654321B');
INSERT INTO Cliente (nombre, primerApellido, segundoApellido, edad, nif) VALUES ('Carlos', 'Navarro', 'Mendez', 35, '23456789C');
INSERT INTO Cliente (nombre, primerApellido, segundoApellido, edad, nif) VALUES ('Ana', 'Ruiz', 'Guerrero', 28, '98765432D');
INSERT INTO Cliente (nombre, primerApellido, segundoApellido, edad, nif) VALUES ('Pedro', 'Castillo', 'Ortega', 33, '34567890E');
